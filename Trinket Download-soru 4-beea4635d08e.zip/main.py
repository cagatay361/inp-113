kelime= input("bir kelime giriniz: ")
print kelime[1:]