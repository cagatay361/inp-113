kelime=input("bir kelime giriniz: ")
print (kelime[0]+kelime[-1])