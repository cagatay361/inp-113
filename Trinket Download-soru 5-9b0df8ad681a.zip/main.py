kelime=input("bir kelime giriniz: ")
sayi = int(input("Sayı giriniz: "))

if sayi > len(kelime):
 print("hata")

else: 
  ilk = kelime[:sayi]
  son = kelime[sayi:]
  print(ilk+"-"+son)