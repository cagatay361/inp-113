sozcuk = input("bir sözcük giriniz:")
print("Sözcük: " + sozcuk)








