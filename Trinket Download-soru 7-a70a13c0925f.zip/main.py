sozcuk =input("bir sözcük giriniz: ")
for harf in sozcuk:
  print (harf+"!")