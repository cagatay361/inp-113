sozcuk =input("bir sözcük giriniz: ")
sayi =int(input("bir sayı giriniz: "))
harf =input("bir harf giriniz: ")

x=sozcuk[:sayi-1]+harf+sozcuk[sayi:]
print x