isim = input("isim giriniz: ")
soyad = input("soyad giriniz: ")
print (isim[0].upper()+"."+soyad[0].upper())
